export interface Language {
    id: number;
    code: string;
    language: string;
}