export interface Types {
    id: number;
    type: string;
}