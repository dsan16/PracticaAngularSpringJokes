export interface Categories{
    id: number;
    category: string;
}